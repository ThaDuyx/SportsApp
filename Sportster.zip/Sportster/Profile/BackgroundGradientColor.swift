//
//  BackgroundGradientColor.swift
//  Sportster
//
//  Created by Christoffer Detlef on 06/10/2020.
//

import UIKit

class BackgroundGradientColor: UIView {
    private let gradientLayer = CAGradientLayer()

    override func awakeFromNib() {
        super.awakeFromNib()

        addGradient()
    }

    override func layoutSubviews() {
        super.layoutSubviews()

        // update gradient
        gradientLayer.frame = self.bounds
    }

    private func addGradient() {
        // declaring colors for your gradient:
        // top color is clear
        let topColor = UIColor.clear.cgColor
        // bottom color is black
        let bottomColor = UIColor.black.cgColor

        gradientLayer.frame = self.frame

        // add colors to the gradientLayer:
        gradientLayer.colors = [topColor, bottomColor]

        // change the startPoint and endPoint to make it appears like it should...
        gradientLayer.startPoint = CGPoint(x: 1.0, y: 0.0)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 1.0)

        // add the gradient to your view (which in my case is gradientView)
        self.layer.insertSublayer(gradientLayer, at: 0)
    }
}
