//
//  DataCollectionCell.swift
//  Sportster
//
//  Created by Christoffer Detlef on 06/10/2020.
//

import UIKit

class DataCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var profilePicturesImage: UIImageView!
}
